﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("CSD 412 Assignment 2");
